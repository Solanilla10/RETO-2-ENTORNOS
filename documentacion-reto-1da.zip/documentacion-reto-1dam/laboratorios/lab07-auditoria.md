# LAB 07 — Auditoría y publicación de la documentación

**Entornos de Desarrollo · 1 hora · Entrega: tag `v1.0-docs`**

## Objetivo

Comprobar si vuestra documentación permite a una persona externa entender y recuperar el proyecto. Lo comprobará otro equipo, sin vuestra ayuda, y después corregiréis lo que encuentre.

## Conocimientos previos

- LAB 01 a 06 entregados.
- Acceso de lectura al repositorio del equipo que os toca auditar (el profesor indica las parejas).

## Desarrollo de la sesión

| Tiempo | Qué se hace |
| --- | --- |
| 25 min | Auditoría del repositorio del otro equipo con la checklist, sin preguntarle nada |
| 10 min | Entrega del informe y explicación breve al equipo auditado |
| 20 min | Corrección de las deficiencias detectadas en vuestro propio repositorio |
| 5 min | Versión final: commit, tag `v1.0-docs` y push |

## Pasos

1. **Clonad el repositorio auditado** en una carpeta nueva. Trabajad solo con lo que hay en él y en su web del remoto: si algo no está escrito, para vosotros no existe.
2. **Completad el informe de auditoría.** Copiad `evidencias/auditoria/plantilla-informe-auditoria.md` de vuestro repositorio como `evidencias/auditoria/auditoria-equipo-<X>.md`. En cada punto, anotad el tiempo que os ha costado y la evidencia: la ruta del archivo o lo que no habéis encontrado.
3. **Señalad las deficiencias** ordenadas por gravedad. Una deficiencia grave es la que impide entender o recuperar el proyecto (por ejemplo, la base de datos no se puede reconstruir con la guía).
4. **Entregad una copia del informe** al equipo auditado: como *issue* en su repositorio si usáis plataforma, o como archivo.
5. **Corregid vuestro repositorio.** Con el informe recibido, cread una rama `docs/auditoria`, corregid al menos una deficiencia (todas las graves si las hay), y añadid el informe recibido como `evidencias/auditoria/informe-recibido.md` con una columna que diga qué se ha corregido y en qué commit.
6. **Versión final.** Integrad la rama en `main` y marcad la versión final de la documentación:

```bash
git switch main
git merge --no-ff docs/auditoria
git push
git tag -a v1.0-docs -m "Documentación del RETO, versión final"
git push origin v1.0-docs
```

Opcional: si usáis GitHub o GitLab, podéis publicar la carpeta `docs/` (incluido el Javadoc) como web con GitHub Pages o GitLab Pages, para que se consulte sin clonar el repositorio.

## Plantillas que se rellenan

- `evidencias/auditoria/plantilla-informe-auditoria.md` (copia para el informe que hacéis)
- `evidencias/auditoria/informe-recibido.md` (el que os entregan, con vuestras correcciones)

## Entregables

- Informe de la auditoría que habéis hecho, en `evidencias/auditoria/`.
- Informe recibido, con las correcciones aplicadas y sus commits.
- Rama `docs/auditoria` integrada y tag `v1.0-docs` en el remoto.

## Checklist de autocorrección

- [ ] Hemos auditado sin pedir ayuda al otro equipo y lo que no encontramos está anotado como tal.
- [ ] Cada punto de la checklist tiene una evidencia (ruta o explicación), no solo un «Sí».
- [ ] Las deficiencias están ordenadas por gravedad y son concretas.
- [ ] Hemos corregido al menos una deficiencia del informe recibido, y todas las graves.
- [ ] Cada corrección está enlazada con su commit.
- [ ] El tag `v1.0-docs` está en el remoto y apunta a la versión con las correcciones.
