# LAB 02 — Documentar el código Java con Javadoc

**Programación + Entornos de Desarrollo · 2 horas · Entrega: tag `lab-02`**

## Objetivo

Al terminar, las clases principales de vuestra aplicación tendrán Javadoc correcto, generado como HTML desde Eclipse, y cualquiera podrá usar vuestros métodos sin leer su código.

## Conocimientos previos

- Clases, atributos, métodos, constructores y modificadores de acceso.
- Excepciones: qué significa que un método lance una.
- Ruta del JDK instalado en vuestro equipo (la carpeta que contiene `bin/javadoc`).

## Tres tipos de comentario que no se deben confundir

| Tipo | Sintaxis | Para quién | Qué dice |
| --- | --- | --- | --- |
| Javadoc | `/** ... */` encima de clase o método | Quien usa la clase | Qué hace, qué recibe, qué devuelve, qué puede fallar |
| Comentario explicativo | `// ...` dentro del código | Quien mantiene el código | Por qué se hace algo de esa forma, cuando no es evidente |
| TODO | `// TODO: ...` | El equipo | Trabajo pendiente concreto. No sustituye al Javadoc |

## Etiquetas que vais a usar

| Etiqueta | Cuándo |
| --- | --- |
| `@param nombre descripción` | Una por cada parámetro, en orden |
| `@return descripción` | Si el método no es `void`; incluid los casos especiales (`null`, lista vacía) |
| `@throws Excepción cuándo` | Por cada excepción que el método lance o declare |
| `@author`, `@version` | En la clase |
| `{@link Clase#metodo}` | Para enlazar con otra clase o método del proyecto |
| `{@code texto}` | Para código dentro de la descripción (`{@code null}`) |

## Pasos

1. **Elegid 3–5 clases principales** (modelo y lógica, no las de prueba). Repartidlas: cada integrante documenta al menos una y la sube con su propio commit.
2. **Generad el esqueleto.** En Eclipse, colocad el cursor encima de un método, escribid `/**` y pulsad Intro: Eclipse crea las etiquetas `@param`, `@return` y `@throws` según la firma.
3. **Escribid el contrato, no el código.** Primera frase: qué hace el método, en tercera persona («Busca…», «Calcula…»). Después, cada parámetro con sus valores válidos y cada caso especial del retorno.
4. **Documentad la clase** con una o dos frases sobre su responsabilidad, `@author` y `@version`.
5. **Revisad los TODO.** Abrid *Window → Show View → Tasks*: Eclipse lista todos los TODO del proyecto. Reescribid los vagos (`// TODO: arreglar`) para que digan qué falta y dónde (`// TODO: validar el formato del email antes de guardar`).
6. **Generad el HTML.** *Project → Generate Javadoc…* y configurad:
   - Javadoc command: `<ruta-del-JDK>/bin/javadoc` (`javadoc.exe` en Windows).
   - Proyecto y paquetes a documentar; visibilidad *Protected* o *Package*.
   - Destination: la carpeta `docs/programacion/javadoc` de vuestro repositorio.
   - En la última pantalla, *Extra Javadoc options*: `-encoding UTF-8 -charset UTF-8 -docencoding UTF-8` para que las tildes salgan bien.
7. **Comprobad.** Abrid `docs/programacion/javadoc/index.html` en el navegador. Elegid un método, leed solo su Javadoc, predecid qué hará con un valor límite y probadlo. Si no coincide, corregid el comentario o el código.
8. **Rellenad `docs/programacion/README.md`**, haced commit y cread el tag `lab-02`.

Si Eclipse falla al generar, el mismo resultado se obtiene desde terminal en la raíz del repositorio:

```bash
javadoc -d docs/programacion/javadoc -sourcepath programacion/src -subpackages <paquete-raiz> -encoding UTF-8 -charset UTF-8 -docencoding UTF-8
```

## Ejemplo: Javadoc que no ayuda

```java
/**
 * Método buscarUsuario.
 * @param id el id
 * @return Usuario
 */
public Usuario buscarUsuario(int id) {
    // TODO: arreglar
    ...
}
```

Repite el nombre del método, no dice qué pasa si el usuario no existe ni qué valores de `id` son válidos, y el TODO no dice qué hay que arreglar.

## Ejemplo: Javadoc útil

```java
/**
 * Gestiona las operaciones sobre los usuarios de la aplicación:
 * alta, búsqueda y baja.
 *
 * @author Equipo 3
 * @version 1.0
 */
public class UsuarioService {

    /**
     * Busca un usuario por su identificador.
     *
     * @param id identificador del usuario; debe ser mayor que 0
     * @return el usuario con ese identificador, o {@code null} si no existe
     * @throws IllegalArgumentException si {@code id} es menor o igual que 0
     * @see Usuario
     */
    public Usuario buscarUsuario(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("El id debe ser positivo: " + id);
        }
        // TODO: sustituir la lista en memoria por una consulta a la tabla usuario
        for (Usuario u : usuarios) {
            if (u.getId() == id) {
                return u;
            }
        }
        return null;
    }
}
```

El Javadoc describe el contrato definitivo; el TODO avisa de que la implementación actual es provisional. Los dos son necesarios y no se sustituyen.

## Plantillas que se rellenan

- `docs/programacion/README.md`

## Entregables

- Clases principales con Javadoc de clase y de todos sus métodos públicos.
- Javadoc HTML generado en `docs/programacion/javadoc/` (subido o ignorado, según indique el profesor).
- TODO del código reescritos de forma concreta.
- `docs/programacion/README.md` y tag `lab-02`.

## Checklist de autocorrección

- [ ] Ningún Javadoc se limita a repetir el nombre del método.
- [ ] Cada método público tiene `@param` por parámetro, `@return` si no es `void` y `@throws` si lanza excepciones.
- [ ] Los casos especiales (`null`, vacío, valores no válidos) están escritos.
- [ ] El HTML generado muestra bien las tildes y todas las clases elegidas.
- [ ] Hemos probado al menos un método contra su Javadoc y coinciden.
- [ ] Ningún TODO dice solo «arreglar», «revisar» o «pendiente».
- [ ] Cada integrante tiene al menos un commit en este laboratorio.
