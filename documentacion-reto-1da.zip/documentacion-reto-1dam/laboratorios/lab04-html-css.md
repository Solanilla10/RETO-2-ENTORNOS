# LAB 04 — Documentar la web HTML y CSS

**Lenguajes de Marcas + Entornos de Desarrollo · 1,5 horas · Entrega: tag `lab-04`**

## Objetivo

Al terminar, alguien que no conoce vuestra web sabrá qué páginas tiene, cómo se enlazan, dónde está cada estilo y cómo cambiar el aspecto sin romperla.

## Conocimientos previos

- Estructura semántica de HTML: `header`, `nav`, `main`, `section`, `footer`, formularios.
- Selectores, clases, variables CSS (`--nombre`) y media queries.
- VS Code con la web del RETO abierta.

## Qué se documenta y qué no

No hay que comentar cada etiqueta ni cada propiedad. Se documenta lo que explica la estructura, lo que hace falta para mantener la web y lo que justifica una decisión. Un comentario como `<!-- párrafo -->` encima de un `<p>` no aporta nada; uno que dice qué bloque empieza y por qué está ahí, sí.

## Pasos

1. **Mapa de navegación.** En `docs/web/estructura.md`, dibujad qué página enlaza con cuál. Podéis usar una lista anidada o un diagrama Mermaid (ver ejemplo).
2. **Finalidad de cada página.** Una tabla con cada archivo HTML, para qué sirve y desde dónde se llega.
3. **Estructura HTML.** Describid los bloques comunes (cabecera, menú, pie) y los componentes importantes de cada página, sobre todo los formularios: qué campos tienen y a qué dato del RETO corresponden.
4. **Comentarios en el código.** Añadid comentarios solo al inicio de cada bloque principal del HTML y de cada sección del CSS.
5. **Organizad y documentad el CSS** en `docs/web/estilos.md`: qué archivos hay y en qué orden se cargan, qué variables existen, qué clases son reutilizables y qué media queries hay.
6. **Decisiones de accesibilidad, diseño adaptable y navegación.** Anotad qué habéis hecho y qué falta: `lang` en `<html>`, `alt` en imágenes, `<label>` en los campos, un solo `<h1>` por página, contraste. Pasad las páginas por el validador del W3C (<https://validator.w3.org/>) y por la auditoría Lighthouse de las herramientas de desarrollo de Chrome, y apuntad los resultados.
7. **Guía rápida** al principio de `estructura.md`: cómo ver la web (abrir `web/index.html` o usar la extensión Live Server de VS Code) y cómo cambiar el color principal o la tipografía.

## Ejemplo: comentarios que sí aportan

```html
<!-- Navegación principal: igual en todas las páginas.
     Si se añade una página, añadirla aquí en todas. -->
<nav aria-label="Navegación principal">
    <ul class="menu-principal">
        <li><a href="index.html">Inicio</a></li>
        <li><a href="contacto.html">Contacto</a></li>
    </ul>
</nav>
```

```css
/* ==============================================
   1. Variables globales
   Cambiar aquí los colores de toda la web
   ============================================== */
:root {
    --color-principal: #1e5aa8;
    --color-texto: #222222;
}

/* ==============================================
   3. Navegación principal (todas las páginas)
   ============================================== */
.menu-principal {
    display: flex;
    gap: 1rem;
}

/* En pantallas estrechas el menú pasa a columna */
@media (max-width: 600px) {
    .menu-principal {
        flex-direction: column;
    }
}
```

## Ejemplo de mapa de navegación en Mermaid

```mermaid
flowchart LR
    index[index.html] --> catalogo[catalogo.html]
    index --> contacto[contacto.html]
    catalogo --> detalle[detalle.html]
    detalle --> reserva[reserva.html]
```

## Plantillas que se rellenan

- `docs/web/README.md` (índice)
- `docs/web/estructura.md`
- `docs/web/estilos.md`

## Entregables

- `docs/web/estructura.md` con guía rápida, mapa, páginas, bloques comunes, formularios y accesibilidad.
- `docs/web/estilos.md` con archivos, variables, clases y media queries.
- HTML y CSS con comentarios al inicio de cada bloque o sección principal.
- Tag `lab-04`.

## Checklist de autocorrección

- [ ] Todas las páginas HTML del proyecto aparecen en el mapa y en la tabla.
- [ ] Cada formulario dice a qué dato del RETO corresponde cada campo.
- [ ] Siguiendo solo `estilos.md`, un compañero ha cambiado el color principal sin tocar nada más.
- [ ] Ningún comentario se limita a repetir el nombre de la etiqueta.
- [ ] Hemos pasado el validador y anotado los resultados, aunque haya errores pendientes.
- [ ] Los errores que no hemos corregido están apuntados para el LAB 05.
