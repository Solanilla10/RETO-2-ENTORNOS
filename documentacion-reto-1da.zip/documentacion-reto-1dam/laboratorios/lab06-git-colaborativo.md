# LAB 06 — Gestionar la documentación mediante Git

**Entornos de Desarrollo · 1,5 horas · Entrega: tag `lab-06`**

## Objetivo

Al terminar, cada integrante habrá mejorado un documento en su propia rama, otro compañero lo habrá revisado y el cambio estará integrado en `main`, con todo el proceso visible en el historial.

## Conocimientos previos

- LAB 01 a 05 integrados en `main`.
- Git básico del LAB 01; en este laboratorio se añaden ramas, `diff`, revisión y `merge`.

## Reparto antes de empezar (5 min)

Cada integrante elige un documento distinto que mejorar y una persona que se lo revise, en ciclo (A revisa a B, B a C, C a A). Podéis partir de lo que no pasasteis en las checklists anteriores o de `pendientes.md`.

| Integrante | Rama | Documento | Revisa |
| --- | --- | --- | --- |
| A | `docs/bbdd-restricciones` | `docs/bbdd/diccionario-datos.md` | B |
| B | `docs/web-formularios` | `docs/web/estructura.md` | C |
| C | `docs/java-servicios` | Javadoc de `ReservaService` | A |

## Pasos

1. **Cread vuestra rama** a partir de un `main` actualizado:

   ```bash
   git switch main
   git pull
   git switch -c docs/<tema>
   ```

2. **Modificad el documento.** Una mejora con sentido, no un retoque de una coma.
3. **Commit descriptivo.** Revisad con `git status` y `git diff` qué vais a subir y haced uno o varios commits con prefijo `docs:`.
4. **Comparad versiones.** `git diff main...docs/<tema>` muestra todo lo que la rama cambia respecto a `main`; `git log --oneline main..docs/<tema>` lista solo sus commits.
5. **Subid la rama** con `git push -u origin docs/<tema>` y pedid la revisión:
   - Con GitHub, GitLab o Gitea: abrid una pull request (o merge request) hacia `main`. El revisor comenta en ella.
   - Sin plataforma: el revisor hace `git fetch`, `git switch docs/<tema>`, lee `git diff main...docs/<tema>` y copia `evidencias/git/plantilla-revision.md` como `evidencias/git/revision-<tema>.md` para rellenarla.
6. **Revisad el trabajo de otro.** Usad las tres preguntas: ¿es correcto?, ¿se entiende sin el autor?, ¿coincide con el proyecto? Pedid al menos un cambio concreto si lo hay. El autor lo aplica con un nuevo commit en la misma rama.
7. **Integrad en `main`** cuando el revisor dé el visto bueno. Con plataforma, se acepta la pull request. Sin plataforma:

   ```bash
   git switch main
   git pull
   git merge --no-ff docs/<tema>
   git push
   ```

   `--no-ff` hace que la rama siga viéndose en el historial.
8. **Comprobad el resultado.** Abrid el documento en la web del remoto y verificad que el cambio está y que los enlaces del README siguen funcionando.
9. **Guardad las evidencias y explicad el proceso.** Cuando todas las ramas estén integradas, generad el historial y rellenad `evidencias/git/proceso.md`. Después, tag `lab-06`.

```bash
git log --oneline --graph --all > evidencias/git/historial.txt
git add evidencias/git/
git commit -m "docs: añadir evidencias del LAB 06"
git push
git tag -a lab-06 -m "LAB 06 entregado"
git push origin lab-06
```

## Ejercicio controlado de conflicto (opcional, repositorio de prácticas)

Los conflictos no se provocan en el repositorio del RETO. Si no os aparece ninguno de forma natural, haced este ejercicio en una carpeta aparte para aprender a resolverlo:

```bash
mkdir practica-conflictos && cd practica-conflictos
git init -b main
echo "# Proyecto" > README.md
git add README.md && git commit -m "docs: README inicial"

git switch -c docs/a
echo "Descripción escrita por A" >> README.md
git commit -am "docs: descripción de A"

git switch main
git switch -c docs/b
echo "Descripción escrita por B" >> README.md
git commit -am "docs: descripción de B"

git switch main
git merge docs/a
git merge docs/b        # aquí aparece el conflicto
```

Para resolverlo: abrid `README.md`, decidid el texto final, borrad las marcas `<<<<<<<`, `=======` y `>>>>>>>`, y después `git add README.md` y `git commit`. Con `git log --oneline --graph` veréis cómo quedan unidas las dos ramas.

## Plantillas que se rellenan

- `evidencias/git/plantilla-revision.md` (una copia por rama revisada, si no usáis plataforma)
- `evidencias/git/proceso.md`

## Entregables

- Una rama `docs/<tema>` por integrante, integrada en `main`.
- Evidencia de revisión: pull requests comentadas o archivos `evidencias/git/revision-<tema>.md`.
- `evidencias/git/historial.txt` y `evidencias/git/proceso.md`.
- Tag `lab-06`.

## Checklist de autocorrección

- [ ] Cada integrante tiene una rama propia con al menos un commit suyo.
- [ ] Ningún cambio de este laboratorio se hizo directamente en `main`.
- [ ] Cada rama tiene una revisión de otra persona, con al menos una pregunta respondida o un cambio pedido.
- [ ] Los mensajes de commit explican qué cambia sin tener que abrir el diff.
- [ ] El grafo de `historial.txt` muestra las ramas uniéndose a `main`.
- [ ] `proceso.md` lo entiende alguien que no estuvo en clase.
