# LAB 01 — El repositorio como centro de documentación

**Entornos de Desarrollo · 1 hora · Entrega: tag `lab-01`**

## Objetivo

Al terminar, vuestro repositorio tendrá un único punto de entrada (`README.md`) desde el que cualquiera llega a toda la documentación del RETO, aunque todavía esté por completar.

## Conocimientos previos

- Sintaxis básica de Markdown: títulos, listas, enlaces, tablas y bloques de código.
- Git básico: `clone`, `status`, `add`, `commit`, `push`.
- Acceso de todo el equipo al repositorio remoto del RETO.

## Pasos

1. **Inventario (15 min).** Abrid juntos el repositorio y anotad qué tenéis ya de cada módulo: clases Java, scripts SQL, diagramas, páginas HTML, hojas CSS. Al lado de cada elemento, apuntad si alguien de fuera lo entendería sin preguntaros.
2. **Qué necesita documentación.** Del inventario, marcad lo que alguien necesitaría para entender, ejecutar o modificar el proyecto. Esa lista os servirá para el índice.
3. **Copiad la plantilla.** Copiad el contenido de `plantilla-repositorio/` (incluidos los archivos ocultos) en la raíz de vuestro repositorio **sin sobrescribir nada que ya exista**. Desde Git Bash (Windows), Linux o macOS: `cp -rn ruta/a/plantilla-repositorio/. ruta/a/vuestro-repositorio/`. La opción `-n` evita sobrescribir archivos existentes. Si ya teníais `README.md` o `.gitignore`, juntad a mano su contenido con el de la plantilla.
4. **Adaptad las rutas.** Si vuestro código ya está organizado de otra forma (por ejemplo, el proyecto de Eclipse en otra carpeta), **no lo mováis**: borrad la carpeta vacía de la plantilla que sobre (`programacion/`, `web/`…) y corregid la tabla «Estructura del repositorio» del README para que diga dónde está cada cosa.
5. **README principal.** Rellenad el `README.md` de la raíz: sustituid todo lo que está entre `< >`. La presentación del RETO debe caber en tres o cuatro frases.
6. **`.gitignore`.** Revisadlo y añadid lo que genere vuestro entorno. La última línea (Javadoc generado) depende de lo que decida vuestro profesor en el LAB 02.
7. **Primer commit documental.** Comprobad con `git status` qué se va a subir, haced el commit y el push, y cread el tag de entrega.

```bash
git status
git add .
git commit -m "docs: crear estructura de documentación y README"
git push
git tag -a lab-01 -m "LAB 01 entregado"
git push origin lab-01
```

## Plantillas que se rellenan

- `README.md` (raíz)
- `.gitignore`

El resto de archivos de `docs/` y `evidencias/` se quedan con su plantilla hasta el laboratorio que les corresponde.

## Entregables

- Estructura `docs/` y `evidencias/` en el repositorio.
- `README.md` principal con presentación, equipo, índice y estructura.
- `.gitignore` revisado.
- Primer commit con prefijo `docs:` y tag `lab-01` en el remoto.

## Checklist de autocorrección

- [ ] La presentación del README la entiende alguien que no conoce el RETO.
- [ ] No queda ningún texto entre `< >` en el README.
- [ ] Todos los enlaces del índice abren un archivo (probadlos en la web del remoto, no solo en local).
- [ ] La tabla de estructura dice dónde está realmente el código de cada módulo.
- [ ] No se ha movido código que ya funcionaba.
- [ ] `git status` está limpio y el tag `lab-01` aparece en el remoto.
