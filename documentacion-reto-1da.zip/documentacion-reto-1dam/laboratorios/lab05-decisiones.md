# LAB 05 — Decisiones técnicas, dependencias y pendientes

**Interdisciplinar · 1 hora · Entrega: tag `lab-05`**

## Objetivo

Al terminar, vuestro repositorio explicará por qué el proyecto es como es, de qué depende para funcionar y qué le falta de verdad, y mostrará cómo una misma funcionalidad atraviesa Java, la base de datos y la web.

## Conocimientos previos

- LAB 02, 03 y 04 entregados: aquí se reutilizan sus TODO y errores pendientes.

## Pasos

1. **Tres decisiones técnicas (20 min).** Elegid tres decisiones que alguien nuevo podría cuestionar, mejor de módulos distintos. Por ejemplo: una relación muchos a muchos con tabla intermedia, una determinada estructura de clases o un CSS compartido por todas las páginas. Escribid cada una en `docs/decisiones-tecnicas.md` siguiendo la plantilla.
2. **Alternativas.** Para cada decisión, al menos una alternativa real que considerasteis y por qué la descartasteis. «No se nos ocurrió otra» no vale: si no la hubo, buscad cuál habría sido.
3. **Dependencias.** Completad el apartado «Cómo empezar» del README principal con lo que hay que tener instalado y con qué versión (JDK, SGBD, conector JDBC, librerías) y qué parte del proyecto necesita a cuál (por ejemplo, la aplicación Java no arranca sin la base de datos creada).
4. **Consolidad los pendientes.** Reunid en `docs/pendientes.md` los TODO de la vista Tasks de Eclipse, lo que falta en la base de datos y los errores del validador web que no hayáis corregido.
5. **Clasificad cada pendiente** como *Pendiente* (falta por hacer), *Error conocido* (existe y falla) o *Mejora* (funciona, pero podría ir mejor), y vinculadlo con su módulo y el archivo o componente exacto.
6. **Trazabilidad.** Elegid una funcionalidad completa del RETO y rellenad `docs/trazabilidad.md`: qué página, qué clase y método, y qué tabla y columnas intervienen.
7. **Comprobad** que los tres documentos están enlazados desde el índice del README, haced commit y cread el tag `lab-05`.

## Plantillas que se rellenan

- `docs/decisiones-tecnicas.md`
- `docs/pendientes.md`
- `docs/trazabilidad.md`
- Apartado «Cómo empezar» del `README.md` principal

## Entregables

- `docs/decisiones-tecnicas.md` con tres decisiones, cada una con alternativas.
- `docs/pendientes.md` con todos los pendientes clasificados y localizados.
- `docs/trazabilidad.md` con una funcionalidad completa.
- Apartado de dependencias en el README principal, y tag `lab-05`.

## Checklist de autocorrección

- [ ] Cada decisión tiene al menos una alternativa descartada y el motivo.
- [ ] Las tres decisiones no son del mismo módulo.
- [ ] Un compañero de otro equipo podría instalar lo necesario leyendo solo el apartado de dependencias.
- [ ] Todos los TODO de la vista Tasks están en `pendientes.md` (o resueltos).
- [ ] Cada pendiente indica archivo, clase, tabla o página concreta, no solo el módulo.
- [ ] La trazabilidad usa nombres reales que existen en el código, la base de datos y la web.
