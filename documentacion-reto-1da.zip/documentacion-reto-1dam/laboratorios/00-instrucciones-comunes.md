# Laboratorios de documentación del RETO · Instrucciones comunes

En estos siete laboratorios vais a documentar el software, la base de datos y la web que ya estáis construyendo en el RETO, y a reunir toda esa documentación en el repositorio Git de vuestro equipo. No hay que programar nada nuevo.

> Documentar no es explicar al profesor lo que hemos hecho. Es permitir que otra persona comprenda, utilice, mantenga y continúe nuestro trabajo.

## Secuencia

| Clase | Laboratorio | Módulos | Duración | Entrega (tag) |
| --- | --- | --- | --- | --- |
| 1 | LAB 01 · Repositorio | Entornos | 1 h | `lab-01` |
| 2–3 | LAB 02 · Javadoc | Programación + Entornos | 2 h | `lab-02` |
| 4–5 | LAB 03 · Bases de datos | BBDD + Entornos | 2 h | `lab-03` |
| 6 | LAB 04 · HTML y CSS | Lenguajes de Marcas + Entornos | 1,5 h | `lab-04` |
| 7 | LAB 05 · Decisiones | Interdisciplinar | 1 h | `lab-05` |
| 8–9 | LAB 06 · Git colaborativo | Entornos | 1,5 h | `lab-06` |
| 10 | LAB 07 · Auditoría | Entornos | 1 h | `v1.0-docs` |

## Cómo es cada ficha

Cada laboratorio tiene siempre los mismos apartados: objetivo, conocimientos previos, pasos, ejemplos, entregables y una checklist de autocorrección. Antes de entregar, repasad la checklist en equipo: si una casilla no se puede marcar con sinceridad, todavía no está terminado.

Las plantillas de todos los documentos están en la carpeta `plantilla-repositorio/` del paquete `documentacion-reto-1dam.zip`. Cada ficha indica cuáles se rellenan.

## Convenciones del equipo

- **Formato:** todos los documentos en Markdown (`.md`), salvo imágenes de diagramas (`.png` o `.svg`).
- **Nombres de archivo:** minúsculas, sin tildes ni espacios, con guiones: `diccionario-datos.md`, no `Diccionario de Datos.md`.
- **Enlaces:** relativos dentro del repositorio (`docs/bbdd/diccionario-datos.md`), nunca rutas de vuestro ordenador (`C:\Users\...`).
- **Commits:** prefijo `docs:` y verbo en infinitivo que diga qué cambia: `docs: añadir diccionario de datos`. Un commit por cambio con sentido, no uno gigante al final.
- **Ramas:** a partir del LAB 06, los cambios de documentación se hacen en ramas `docs/<tema>` y se integran en `main` tras la revisión de un compañero.
- **Quién hace qué:** en cada laboratorio, cada integrante firma con su usuario de Git al menos un commit. El historial es la prueba del reparto.

## Cómo se entrega

Cada laboratorio termina con un tag anotado en `main`, subido al remoto:

```bash
git switch main
git pull
git tag -a lab-01 -m "LAB 01 entregado"
git push origin lab-01
```

El tag es la entrega: el profesorado revisará el repositorio tal y como estaba en ese momento. Si después mejoráis algo, se verá en el historial y cuenta a vuestro favor en la dimensión de mejora.

## Cómo se evalúa

Tres preguntas para todo lo que escribáis:

1. ¿Es técnicamente correcto?
2. ¿Lo entiende alguien que no lo ha escrito?
3. ¿Coincide con lo que el proyecto hace de verdad?

| Dimensión | Peso |
| --- | --- |
| Documentación Java y Javadoc | 25 % |
| Documentación de la base de datos | 25 % |
| Documentación HTML/CSS | 15 % |
| Organización y claridad del repositorio | 15 % |
| Uso de Git para mantener la documentación | 10 % |
| Revisión, coherencia y mejora | 10 % |

Cada dimensión se valora en cuatro niveles: inicial, básico, competente y avanzado.
