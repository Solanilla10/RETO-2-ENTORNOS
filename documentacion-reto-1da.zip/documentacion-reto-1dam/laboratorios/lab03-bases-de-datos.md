# LAB 03 — Documentar el modelo de datos

**Bases de Datos + Entornos de Desarrollo · 2 horas · Entrega: tag `lab-03`**

## Objetivo

Al terminar, una persona que no ha visto vuestro proyecto podrá entender la estructura, relaciones y restricciones de vuestra base de datos y reconstruirla en su ordenador solo con lo que hay en `docs/bbdd/` y `bbdd/sql/`.

## Conocimientos previos

- Modelo entidad-relación: entidades, atributos, relaciones y cardinalidades.
- Paso a modelo relacional: tablas, claves primarias y foráneas, tablas intermedias para N:M.
- `CREATE TABLE` con restricciones (`PRIMARY KEY`, `FOREIGN KEY`, `UNIQUE`, `NOT NULL`, `CHECK`).

Los ejemplos usan MySQL/MariaDB. Si en el módulo usáis otro SGBD, cambiad solo los comandos de exportación e importación.

## Pasos

1. **Actualizad el DER.** Comprobad que coincide con las tablas que existen hoy, no con el primer diseño. Exportadlo como `docs/bbdd/modelo-er.png` desde la herramienta del módulo. En MySQL Workbench se puede obtener de la base real con *Database → Reverse Engineer* y exportar con *File → Export → Export as PNG*.
2. **Revisad entidades y cardinalidades.** Para cada relación, escribid una frase que la lea en los dos sentidos: «Un usuario hace 0 o muchas reservas; cada reserva pertenece a un solo usuario».
3. **Documentad el modelo relacional** en `docs/bbdd/modelo-relacional.md`: una línea por tabla con su clave primaria marcada como PK y sus claves foráneas indicando a qué tabla apuntan.
4. **Rellenad el diccionario de datos** en `docs/bbdd/diccionario-datos.md`: una tabla por cada tabla de la base de datos, con todas sus columnas.
5. **Explicad restricciones y relaciones**: qué pasa al borrar un registro referenciado (`ON DELETE`), qué columnas son `UNIQUE` y por qué, qué comprueba cada `CHECK`.
6. **Ordenad los scripts SQL** en `bbdd/sql/` numerados por orden de ejecución: `01-esquema.sql` (tablas) y `02-datos-prueba.sql` (inserts). Si solo tenéis la base creada a mano, exportad el esquema con:

   ```bash
   mysqldump -u root -p --no-data <nombre_bd> > bbdd/sql/01-esquema.sql
   ```

7. **Completad la guía de reconstrucción** en `docs/bbdd/README.md` y probadla: otro integrante borra su copia local de la base de datos y la reconstruye siguiendo solo la guía.

## Ejemplo de modelo relacional

```text
USUARIO (id_usuario PK, nombre, email UNIQUE, fecha_alta)
RESERVA (id_reserva PK, fecha, id_usuario FK → USUARIO.id_usuario)
```

Relación USUARIO–RESERVA: 1:N. Un usuario hace 0 o muchas reservas; cada reserva pertenece a un solo usuario. Si se borra un usuario con reservas, el borrado se rechaza (`ON DELETE RESTRICT`).

Ejemplo genérico: cada equipo usa sus propias entidades.

## Opcional: el DER dentro del Markdown

GitHub y GitLab dibujan diagramas Mermaid escritos dentro de un `.md`. La ventaja es que el diagrama queda versionado como texto y `git diff` muestra qué ha cambiado. Se escribe dentro de un bloque de código con el lenguaje `mermaid`:

```mermaid
erDiagram
    USUARIO ||--o{ RESERVA : realiza
    USUARIO {
        int id_usuario PK
        varchar nombre
        varchar email UK
        date fecha_alta
    }
    RESERVA {
        int id_reserva PK
        date fecha
        int id_usuario FK
    }
```

## Plantillas que se rellenan

- `docs/bbdd/README.md` (índice y guía de reconstrucción)
- `docs/bbdd/modelo-relacional.md`
- `docs/bbdd/diccionario-datos.md`
- `bbdd/sql/01-esquema.sql` y `bbdd/sql/02-datos-prueba.sql` (o vuestros scripts, renombrados)
- `docs/bbdd/modelo-er.png` (lo añadís vosotros)

## Entregables

- `docs/bbdd/modelo-er.png` (o diagrama Mermaid) actualizado.
- `docs/bbdd/modelo-relacional.md` con PK, FK y cardinalidades explicadas.
- `docs/bbdd/diccionario-datos.md` con todas las tablas y columnas.
- Scripts en `bbdd/sql/` numerados por orden de ejecución.
- `docs/bbdd/README.md` con la guía de reconstrucción probada, y tag `lab-03`.

## Checklist de autocorrección

- [ ] El DER coincide con las tablas que existen hoy en la base de datos.
- [ ] Cada relación tiene su cardinalidad explicada con una frase en los dos sentidos.
- [ ] Todas las tablas del esquema aparecen en el diccionario, con todas sus columnas.
- [ ] Cada FK dice a qué tabla apunta y qué ocurre al borrar.
- [ ] Los scripts se ejecutan en orden sin errores sobre una base vacía.
- [ ] Alguien del equipo que no escribió la guía ha reconstruido la base siguiendo solo la guía.
- [ ] No hay contraseñas reales en los scripts ni en la documentación.
