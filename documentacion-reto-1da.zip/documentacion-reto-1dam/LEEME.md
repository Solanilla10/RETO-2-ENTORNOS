# Documentación técnica del RETO · 1.º DAM

Paquete de trabajo para los siete laboratorios de documentación de **Entornos de Desarrollo**, en colaboración con Programación, Bases de Datos y Lenguajes de Marcas.

No hay que programar nada nuevo: vais a documentar el software, la base de datos y la web que ya estáis construyendo en el RETO, y a reunirlo todo en el repositorio Git de vuestro equipo.

## Qué contiene

| Carpeta | Contenido |
| --- | --- |
| `laboratorios/` | Instrucciones comunes y las siete fichas de trabajo, en orden |
| `plantilla-repositorio/` | Estructura de carpetas y plantillas de todos los documentos que vais a entregar |

## Por dónde empezar

1. Leed `laboratorios/00-instrucciones-comunes.md`.
2. En el LAB 01 copiaréis el contenido de `plantilla-repositorio/` a la raíz de vuestro repositorio del RETO.
3. En cada laboratorio rellenaréis las plantillas que indica su ficha.

## Qué se rellena en cada laboratorio

| Laboratorio | Duración | Archivos de la plantilla |
| --- | --- | --- |
| LAB 01 · Repositorio | 1 h | `README.md`, `.gitignore` |
| LAB 02 · Javadoc | 2 h | `docs/programacion/README.md` + Javadoc en vuestro código |
| LAB 03 · Bases de datos | 2 h | `docs/bbdd/*`, `bbdd/sql/*` |
| LAB 04 · HTML y CSS | 1,5 h | `docs/web/*` |
| LAB 05 · Decisiones | 1 h | `docs/decisiones-tecnicas.md`, `docs/pendientes.md`, `docs/trazabilidad.md` |
| LAB 06 · Git colaborativo | 1,5 h | `evidencias/git/*` |
| LAB 07 · Auditoría | 1 h | `evidencias/auditoria/*` |

## Aviso: archivos ocultos

La plantilla incluye archivos que empiezan por punto (`.gitignore`, `.gitkeep`). En Windows y macOS pueden no verse en el explorador. Activad «mostrar archivos ocultos» antes de copiar, o copiad desde Git Bash o la terminal como indica el LAB 01.

Los archivos `.gitkeep` solo sirven para que Git guarde carpetas vacías. Cuando la carpeta tenga contenido, se pueden borrar.
